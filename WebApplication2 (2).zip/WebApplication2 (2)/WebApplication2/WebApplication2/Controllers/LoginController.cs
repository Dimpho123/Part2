﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;
using System.Data.SqlClient;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using System.Security.Claims;



namespace WebApplication2.Controllers
{


    public class LoginController : Controller
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;

        [HttpGet]
        public ActionResult login()
        {
            return View();
        }
        void connectionString()
        {
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=website;Integrated Security=True";
        }
        [HttpPost]
        public ActionResult Verify(Login l)
        {
            connectionString();
            con.Open();
            com.Connection = con;
            com.CommandText = "Select * from userinfo2 where email='" + l.email + "' and Password='" + l.Password + "'";
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                con.Close();
                return View("Verify");
            }
            else
            {
                con.Close();
                return View("Error");
            }
        }
        //[HttpPost]
        //  public IActionResult login(string email, string password)
        //{
        //    if(!string.IsNullOrEmpty(email) && string.IsNullOrEmpty(password))
        //    {
        //        return RedirectToAction("Login");

        //    }

        //    ClaimsIdentity identity = null;
        //    bool isAuthenticate = false;
        //    if (email == "admin" && password == "a")
        //    {
        //        identity = new ClaimsIdentity(new[]
        //        {
        //            new Claim(ClaimTypes.Name,email),
        //            new Claim(ClaimTypes.Role,"Admin")
        //        }, CookieAuthenticationDefaults.AuthenticationScheme);
        //        isAuthenticate = true;
        //    }
        //    if (email == "demo" && password == "c")
        //    {
        //        identity = new ClaimsIdentity(new[]
        //        {
        //            new Claim(ClaimTypes.Name,email),
        //            new Claim(ClaimTypes.Role,"User")
        //        }, CookieAuthenticationDefaults.AuthenticationScheme);
        //        isAuthenticate = true;
        //    }
        //    if(isAuthenticate)
        //    {
        //        var principal = new ClaimsIdentity(identity);
        //        var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
        //        return RedirectToAction("Index", "Home");
        //    }
        //    return View();
        //    }
        //}


    }
}

