﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class GoodsAllocation
    {
        //Declaring Variables

        //[HttpPost]
        //public IActionResult login(string email, string password)
        //{
        //    if (!string.IsNullOrEmpty(email) && string.IsNullOrEmpty(password))
        //    {
        //        return RedirectToAction("Login");

        //    }

        //    ClaimsIdentity identity = null;
            //    bool isAuthenticate = false;
            //    if (email == "admin" && password == "a")
            //    {
            //        identity = new ClaimsIdentity(new[]
            //        {
            //            new Claim(ClaimTypes.Name,email),
            //            new Claim(ClaimTypes.Role,"Admin")
            //        }, CookieAuthenticationDefaults.AuthenticationScheme);
            //        isAuthenticate = true;
            //    }
            //    if (email == "demo" && password == "c")
            //    {
            //        identity = new ClaimsIdentity(new[]
            //        {
            //            new Claim(ClaimTypes.Name,email),
            //            new Claim(ClaimTypes.Role,"User")
            //        }, CookieAuthenticationDefaults.AuthenticationScheme);
            //        isAuthenticate = true;
            //    }
            //    if(isAuthenticate)
            //    {
            //        var principal = new ClaimsIdentity(identity);
            //        var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            //        return RedirectToAction("Index", "Home");
            //    }
            //    return View();
            //    }
            //}
        }
    }
}
